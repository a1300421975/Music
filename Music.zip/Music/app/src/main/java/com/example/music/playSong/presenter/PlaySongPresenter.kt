package com.example.music.playSong.presenter

import com.example.music.playSong.model.PlaySongModel

class PlaySongPresenter:IPlaySongPresenter{

    private val playSongModel = PlaySongModel()



}