package com.example.music.playSong.presenter

interface IPlaySongPresenter{


}