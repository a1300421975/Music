package com.example.music.playSong.model

class PlaySongModel:IPlaySongModel{

    override fun getBitmap(url: String) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }


}