package com.example.music.playSong.model

interface IPlaySongModel{

    fun getBitmap(url:String)


}