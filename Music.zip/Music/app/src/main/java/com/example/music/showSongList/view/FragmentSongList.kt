package com.example.music.showSongList.view


import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.music.R
import com.example.music.base.BaseFragment
import com.example.music.data.SongListTransform
import com.example.music.showSongList.adapter.SongListRecyclerAdapter
import com.example.music.utils.SongListUtil
import com.example.music.utils.runOnNewThread

class FragmentSongList : Fragment() {

    private lateinit var songListRecycler: RecyclerView
    private val songListRecyclerAdapter = SongListRecyclerAdapter()
    private val handler = Handler()

    protected var view_:View? = null
    private var parent:ViewGroup? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if (view_ != null){
            if (view_!!.parent != null){
                parent = view_!!.parent as ViewGroup
                parent!!.removeView(view_)
            }
            return view_
        }

        val view = inflater.inflate(R.layout.fragment_song_list, container, false)
        view_ = view
        initView(view)
        initData()
        return view
    }

    private fun initView(view:View){
        songListRecycler = view.findViewById(R.id.song_list_recycler)
        songListRecycler.layoutManager = LinearLayoutManager(this.context)
        songListRecycler.adapter = songListRecyclerAdapter
    }

    private fun initData(){
        freshSongList()
    }

    private fun freshSongList(){
        val songList = ArrayList<SongListTransform>()
        SongListUtil.getSongList(SongListUtil.URL_QQ){
            handler.post {
                Log.d("aaa",it.toString())
                songListRecyclerAdapter.freashSongList(it)
                songListRecyclerAdapter.notifyDataSetChanged()
            }
        }

//        SongListUtil.getSongList(SongListUtil.URL_WYY){
//            songList.addAll(it)
//            handler.post {
//                songListRecyclerAdapter.freashSongList(songList)
//                songListRecyclerAdapter.notifyDataSetChanged()
//            }
//        }
    }
}
