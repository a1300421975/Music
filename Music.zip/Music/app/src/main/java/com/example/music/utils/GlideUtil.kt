package com.example.music.utils

import android.content.Context
import android.widget.ImageView
import com.bumptech.glide.Glide

object GlideUtil{

    fun setImage(url:String,imageView: ImageView,context:Context){
        Glide.with(context)
            .load(url)
            .into(imageView)
    }

}